# Attention seeker

Let's recreate the following effect:

![Example](example.png)

![Example](example.gif)